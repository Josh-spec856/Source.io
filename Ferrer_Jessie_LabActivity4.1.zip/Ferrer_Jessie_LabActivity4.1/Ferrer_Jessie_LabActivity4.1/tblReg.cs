﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ferrer_Jessie_LabActivity4._1
{
    public partial class tblReg
    {
        public static void createRegister(string fname, String lname, string email, string contact, string id, string pass)
        {
            Ferrer_Jessie_LabActivity4._1.RegisterEntities jessie = new Ferrer_Jessie_LabActivity4._1.RegisterEntities();
            tblReg ferrer = new tblReg
            {
                Fname = fname,
                Lname = lname,
                Email = email,
                Contact = contact,
                Username = id,
                Password = pass
            };
            jessie.tblRegs.AddObject(ferrer);
            jessie.SaveChanges();
        }
        public static List<tblReg> readRegister()
        {
            Ferrer_Jessie_LabActivity4._1.RegisterEntities jessie = new Ferrer_Jessie_LabActivity4._1.RegisterEntities();
            List<tblReg> Reglist = (from a in jessie.tblRegs orderby a.Fname select a).ToList();
            if (Reglist != null)
            {
                return Reglist;
            }
            else
            {
                return null;
            }

        }
        public static void updateregister(string newfname, string newlname, string newemail, string newcontact, string id, string newpass)
        {
            Ferrer_Jessie_LabActivity4._1.RegisterEntities jessie = new Ferrer_Jessie_LabActivity4._1.RegisterEntities();
            tblReg Register = (from a in jessie.tblRegs where a.Username == id select a).FirstOrDefault();
            if (Register != null)
            {
                Register.Fname = newfname;
                Register.Lname = newlname;
                Register.Email = newemail;
                Register.Contact = newcontact;
                Register.Password = newpass;

                jessie.SaveChanges();
            }
        }
        public static void deleteRegister(string id)
        {
            Ferrer_Jessie_LabActivity4._1.RegisterEntities jessie = new Ferrer_Jessie_LabActivity4._1.RegisterEntities();
            tblReg Register = (from a in jessie.tblRegs where a.Username == id select a).FirstOrDefault();
            if (Register != null)
            {
                jessie.tblRegs.DeleteObject(Register);
                jessie.SaveChanges();
            }
        }
    }
}