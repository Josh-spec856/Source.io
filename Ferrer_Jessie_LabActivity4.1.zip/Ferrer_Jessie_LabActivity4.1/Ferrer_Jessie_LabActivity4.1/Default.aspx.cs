﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Ferrer_Jessie_LabActivity4._1
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            popGrid();
        }
        protected void popGrid()
        {
            GridView1.DataSource = tblReg.readRegister();
            GridView1.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            tblReg.createRegister(txtfname.Text, txtlname.Text, txtemail.Text, txtnum.Text, txtuser.Text, txtpass.Text);
            popGrid();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            tblReg.updateregister(txtfname.Text, txtlname.Text, txtemail.Text, txtnum.Text, txtuser.Text, txtpass.Text);
            popGrid();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            tblReg.deleteRegister(txtuser.Text);
            popGrid();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtfname.Text = GridView1.SelectedRow.Cells[1].Text;
            txtlname.Text = GridView1.SelectedRow.Cells[2].Text;
            txtemail.Text = GridView1.SelectedRow.Cells[3].Text;
            txtnum.Text = GridView1.SelectedRow.Cells[4].Text;
            txtuser.Text = GridView1.SelectedRow.Cells[5].Text;
            txtpass.Text = GridView1.SelectedRow.Cells[6].Text;
        }
    }
}
